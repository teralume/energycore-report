﻿# EnergyCore TB1 - archivos complementarios

Este paquete conserva evidencia tÃ©cnica verificable de la entrega acumulativa:

- fuente Markdown del Project Report;
- Sprint Planning detallados y backlog trazable preparado para Trello;
- resultado del despliegue de Cloud Run sin credenciales;
- contrato OpenAPI recuperado del servicio;
- resultados JSON de smoke tests de energÃ­a, potencia y concurrencia;
- APK release de Android y su checksum SHA-1.

La exposiciÃ³n reutilizada de AV1 se entrega como archivo MP4 separado. El About-the-Product permanece publicado en YouTube y Microsoft Stream, con sus enlaces dentro del informe.
